﻿namespace P03_SalesDatabase
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=Sales;Integrated Security=True;";
    }
}
