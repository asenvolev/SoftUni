﻿namespace BashSoft.Contracts
{
    public interface IInterpreter
    {
        void InterpretCommand(string command);
    }
}