﻿namespace ProductsShop.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=ProductsShop;Integrated Security=True;";
    }
}
