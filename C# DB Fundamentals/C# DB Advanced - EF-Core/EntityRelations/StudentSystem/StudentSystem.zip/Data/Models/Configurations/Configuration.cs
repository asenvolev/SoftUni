﻿namespace P01_StudentSystem.Data.Models.Configurations
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=StudentSystem;Integrated Security=True;";
    }
}
