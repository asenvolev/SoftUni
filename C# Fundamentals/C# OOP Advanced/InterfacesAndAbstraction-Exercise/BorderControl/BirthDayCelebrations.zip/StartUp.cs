﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BorderControl
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var input = Console.ReadLine();
            var identities = new List<IIdentifiable>();
            var birthdays = new List<IBirhtable>();
            while (input!="End")
            {
                var tokens = input.Split();
                switch (tokens[0])
                {
                    default:
                        break;
                    case "Citizen":
                        var citizen = new Citizen(tokens[1], int.Parse(tokens[2]), tokens[3], tokens[4]);
                        identities.Add(citizen);
                        birthdays.Add(citizen);
                        break;
                    case "Pet":
                        var pet = new Pet(tokens[1],tokens[2]);
                        birthdays.Add(pet);
                        break;
                    case "Robot":
                        var robot = new Robot(tokens[1], tokens[2]);
                        identities.Add(robot);
                        break;
                }
                input = Console.ReadLine();
            }
            input = Console.ReadLine();
            foreach (var item in birthdays.Where(x=>x.BirthDate.EndsWith(input)))
            {
                Console.WriteLine(item.BirthDate);
            }
        }
    }
}
