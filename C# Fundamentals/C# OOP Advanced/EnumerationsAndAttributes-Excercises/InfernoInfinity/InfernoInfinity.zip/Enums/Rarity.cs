﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InfernoInfinity
{
    public enum Rarity
    {
        Common= 1,
        Uncommon = 2,
        Rare = 3,
        Epic = 5
    }
}
