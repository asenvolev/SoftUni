﻿using System;
using System.Collections.Generic;
using System.Linq;

public class StartUp
{
    static Dictionary<int, Tree<int>> nodeByValue = new Dictionary<int, Tree<int>>();

    public static void Main()
    {
        ReadTree();
        PrintMiddleNodes();
    }

    static void PrintMiddleNodes()
    {
        var nodes = nodeByValue
            .Values
            .Where(x => x.Parent != null && x.Children.Any())
            .Select(x => x.Value)
            .OrderBy(x => x)
            .ToArray();

        Console.WriteLine($"Middle nodes: {string.Join(" ",nodes)}");
    }

    public static void FindAllLeafNodes(Tree<int> node, List<int> leafs)
    {
        if (node.Children.Any())
        {
            foreach (var child in node.Children)
            {
                FindAllLeafNodes(child,leafs);
            }
        }
        else
        {
            leafs.Add(node.Value);
        }
    }

    public static void PrintTree(Tree<int> node, int indent = 0)
    {
        Console.Write(new string(' ', 2 * indent));
        Console.WriteLine(node.Value);
        foreach (var child in node.Children)
        {
            PrintTree(child, indent+1);
        }
    }

    public static Tree<int> GetRootNode()
    {
        return nodeByValue.Values.FirstOrDefault(x => x.Parent == null);
    }

    public static void ReadTree()
    {
        var nodeCount = int.Parse(Console.ReadLine());
        for (int i = 0; i < nodeCount-1; i++)
        {
            var edge = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            int parentValue = edge[0];
            int childValue = edge[1];
            AddEdge(parentValue, childValue);
        }
    }

    public static void AddEdge(int parent,int child)
    {
        var parentNode = GetTreeNodeByValue(parent);
        var childNode = GetTreeNodeByValue(child);

        parentNode.Children.Add(childNode);
        childNode.Parent = parentNode;
    }

    public static Tree<int> GetTreeNodeByValue(int value)
    {
        if (!nodeByValue.ContainsKey(value))
        {
            nodeByValue.Add(value, new Tree<int>(value));
        }
        return nodeByValue[value];
    }
}

