﻿namespace P03_FootballBetting.Data.Models
{
    public enum GameResult
    {
        HomeTeamWin = 1,
        AwayTeamWin = 2,
        Draw = 0,
    }
}