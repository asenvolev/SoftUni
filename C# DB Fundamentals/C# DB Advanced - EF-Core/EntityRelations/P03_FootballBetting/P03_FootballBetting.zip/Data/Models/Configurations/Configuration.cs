﻿namespace P03_FootballBetting.Data.Models.Configurations
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=FootballBetting;Integrated Security=True;";
    }
}
