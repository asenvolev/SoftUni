﻿namespace BusTicketSystem.Models
{
    public enum Status
    {
        departed,
        arrived,
        delayed,
        cancelled
    }
}