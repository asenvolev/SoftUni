﻿using System;
using System.Collections.Generic;

public class AStar
{
    public AStar(char[,] map)
    {
        throw new NotImplementedException();
    }

    public static int GetH(Node current, Node goal)
    {
        throw new NotImplementedException();
    }

    public IEnumerable<Node> GetPath(Node start, Node goal)
    {
        throw new NotImplementedException();
    }
}

