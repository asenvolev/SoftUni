﻿using PhotoShare.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace PhotoShare.Client.Core
{
    public static class Session
    {
        public static User User { get; set; }
    }
}
