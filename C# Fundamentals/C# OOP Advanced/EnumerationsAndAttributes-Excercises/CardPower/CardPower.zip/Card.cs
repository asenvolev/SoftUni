﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardPower
{
    public class Card
    {
        private CardRank rank;
        private CardSuits suit;
        public Card(string rank, string suit)
        {
            this.rank = (CardRank)Enum.Parse(typeof(CardRank), rank);
            this.suit = (CardSuits)Enum.Parse(typeof(CardSuits), suit);
        }
        public override string ToString()
        {
            return $"Card name: {rank} of {suit}; Card power: {(int)rank + (int)suit}";
        }
    }
}
