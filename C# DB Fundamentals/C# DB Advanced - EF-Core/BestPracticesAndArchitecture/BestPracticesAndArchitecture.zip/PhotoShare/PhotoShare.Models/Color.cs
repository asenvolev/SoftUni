﻿namespace PhotoShare.Models
{
    public enum Color
    {
        White,
        Green,
        Blue,
        Pink,
        Yellow,
        Black,
        Cyan,
        Magenta,
        Red,
        Purple,
        WhiteBlackGradient
    }
}
