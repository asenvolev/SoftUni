﻿namespace BusTicketSystem.Models
{
    public enum Gender
    {
        Male,
        Female,
        NotSpecified
    }
}