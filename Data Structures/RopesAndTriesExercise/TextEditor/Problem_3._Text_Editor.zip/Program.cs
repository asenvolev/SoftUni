﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Problem_3._Text_Editor
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, bool> loggedUsers = new Dictionary<string, bool>();

            ITextEditor textEditor = new TextEditor();

            Func<string, string, bool> prefixUserName = (key, word) => word.Substring(0,key.Length).Equals(key);

            Regex regex = new Regex("(?<=\")(?<text>.*)(?=\")");

            string input = string.Empty;

            while ((input = Console.ReadLine()) != "end")
            {
                Match matchText = regex.Match(input);

                string[] tokens = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).ToArray();

                switch (tokens[0])
                {
                    case "login":
                        string userName = tokens[1];
                        loggedUsers[userName] = true;
                        textEditor.Login(userName);
                        break;
                    case "logout":
                        userName = tokens[1];
                        if (loggedUsers.ContainsKey(userName))
                        {
                            loggedUsers[userName] = false;
                        }
                        textEditor.Logout(userName);
                        break;
                    case "users":
                        string prefix = GetPrefix(tokens);
                        List<string> users = loggedUsers.Where(x => x.Value&& prefixUserName(prefix, x.Key)).Select(x => x.Key).ToList();
                        PrintUsers(users);
                        break;
                    default:
                        userName = tokens[0];

                        if (!loggedUsers.ContainsKey(userName) || !loggedUsers[userName]) continue;

                        string text = matchText.Groups["text"].Value;

                        switch (tokens[1])
                        {
                            case "insert":
                                if (!matchText.Success) continue;
                                textEditor.Insert(userName, int.Parse(tokens[2]), text);
                                break;
                            case "prepend":
                                if (!matchText.Success) continue;
                                textEditor.Prepend(userName, text);
                                break;
                            case "substring":
                                textEditor.Substring(userName, int.Parse(tokens[2]), int.Parse(tokens[3]));
                                break;
                            case "delete":
                                textEditor.Delete(userName, int.Parse(tokens[2]), int.Parse(tokens[3]));
                                break;
                            case "clear":
                                textEditor.Clear(userName);
                                break;
                            case "length":
                                Console.WriteLine(textEditor.Length(userName));
                                break;
                            case "print":
                                Console.WriteLine(textEditor.Print(userName));
                                break;
                            case "undo":
                                textEditor.Undo(userName);
                                break;
                        }
                        break;
                }
            }
        }

        private static string GetPrefix(string[] tokens)
        {
            string prefix = "";
            if (tokens.Length != 1)
            {
                prefix = tokens[1];
            }

            return prefix;
        }

        private static void PrintUsers(List<string> users)
        {
            foreach (var user in users)
            {
                Console.WriteLine(user);
            }
        }
    }
}
