﻿namespace BookShop
{
    using System;
    using System.Linq;
    using System.Text;
    using System.Globalization;

    using BookShop.Data;
    using BookShop.Initializer;
    using BookShop.Models;

    public class StartUp
    {
        public static void Main()
        {
            var input = Console.ReadLine();
            using (var db = new BookShopContext())
            {
                Console.WriteLine(GetBookTitlesContaining(db,input));
            }
        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            int enumValue = -1;
            if (command.ToLower() == "minor")
            {
                enumValue = 0;
            }
            else if (command.ToLower() == "teen")
            {
                enumValue = 1;
            }
            else if (command.ToLower() == "adult")
            {
                enumValue = 2;
            }

            var titles = context.Books.Where(b => b.AgeRestriction == (AgeRestriction)enumValue)
                .Select(t => t.Title).OrderBy(x=>x).ToArray();

            return string.Join(Environment.NewLine, titles);
        }

        public static string GetGoldenBooks(BookShopContext context)
        {
            var goldenBooksTitles = context.Books
                .Where(b => b.EditionType == (EditionType)2 && b.Copies<5000)
                .OrderBy(b=>b.BookId)
                .Select(t => t.Title)
                .ToArray();

            return string.Join(Environment.NewLine, goldenBooksTitles);
        }

        public static string GetBooksByPrice(BookShopContext context)
        {                      
            var sb = new StringBuilder();
            context.Books
            .Where(b => b.Price > 40)
            .OrderByDescending(b => b.Price)
            .Select(b => new
            {
                Title = b.Title,
                Price = b.Price
            })
            .ToList()
            .ForEach(b => sb.AppendLine($"{b.Title} - ${b.Price:F2}"));
            return sb.ToString().Trim();
        }

        public static string GetBooksNotRealeasedIn(BookShopContext context, int year)
        {
            var BooksNotRealeasedIn = context.Books
                .Where(b => b.ReleaseDate.Value.Year != year)
                .OrderBy(b => b.BookId)
                .Select(t => t.Title)
                .ToArray();

            return string.Join(Environment.NewLine, BooksNotRealeasedIn);
        }

        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            var categories = input
                .Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x=>x.ToLower())
                .ToList();

            var booksByCategory = context.Books
                .Where(b => b.BookCategories.Any(c => categories.Contains(c.Category.Name.ToLower())))
                .Select(b => b.Title)
                .OrderBy(x => x)
                .ToList();

            return string.Join(Environment.NewLine, booksByCategory);
        }

        public static string GetBooksReleasedBefore(BookShopContext context, string date)
        {
            var parsedDate = DateTime.ParseExact(date, "dd-MM-yyyy", null);

            var sb = new StringBuilder();

            context.Books
                .Where(b => b.ReleaseDate < parsedDate)
                .OrderByDescending(b => b.ReleaseDate)
                .Select(b =>new
                {
                    Info = $"{b.Title} - {b.EditionType} - ${b.Price:f2}"
                })
                .ToList()
                .ForEach(b=> sb.AppendLine(b.Info));

            return sb.ToString().TrimEnd();
        }

        public static string GetAuthorNamesEndingIn(BookShopContext context, string input)
        {
            var sb = new StringBuilder();

            context.Authors
                .Where(a=>a.FirstName.EndsWith(input))
                .OrderBy(a => a.FirstName)
                .ThenBy(a=>a.LastName)
                .Select(a => new
                {
                    FullName = $"{a.FirstName} {a.LastName}"
                })
                .ToList()
                .ForEach(a => sb.AppendLine(a.FullName));

            return sb.ToString().TrimEnd();
        }

        public static string GetBookTitlesContaining(BookShopContext context, string input)
        {
            var BookTitlesContaining = context.Books
                .Where(b => b.Title.ToLower().Contains(input.ToLower()))
                .Select(b => b.Title)
                .OrderBy(t => t)
                .ToArray();

            return string.Join(Environment.NewLine, BookTitlesContaining);
        }
    }
}
