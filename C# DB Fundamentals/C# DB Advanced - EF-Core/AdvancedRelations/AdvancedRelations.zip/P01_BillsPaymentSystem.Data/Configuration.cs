﻿namespace P01_BillsPaymentSystem.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=BillsPaymentSystem;Integrated Security=True;";
    }
}
