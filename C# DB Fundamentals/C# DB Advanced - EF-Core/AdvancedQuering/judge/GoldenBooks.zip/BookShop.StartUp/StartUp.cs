﻿namespace BookShop
{
    using System.Linq;
    using System;

    using BookShop.Data;
    using BookShop.Initializer;
    using BookShop.Models;

    public class StartUp
    {
        public static void Main()
        {
            using (var db = new BookShopContext())
            {
                //DbInitializer.ResetDatabase(db);

                //var command = Console.ReadLine();
                //Console.WriteLine(GetBooksByAgeRestriction(db, command));

                Console.WriteLine(GetGoldenBooks(db));
            }
        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            int enumValue = -1;
            if (command.ToLower() == "minor")
            {
                enumValue = 0;
            }
            else if (command.ToLower() == "teen")
            {
                enumValue = 1;
            }
            else if (command.ToLower() == "adult")
            {
                enumValue = 2;
            }

            var titles = context.Books.Where(b => b.AgeRestriction == (AgeRestriction)enumValue)
                .Select(t => t.Title).OrderBy(x=>x).ToArray();

            return string.Join(Environment.NewLine, titles);
        }

        public static string GetGoldenBooks(BookShopContext context)
        {
            var goldenBooksTitles = context.Books
                .Where(b => b.EditionType == (EditionType)2 && b.Copies<5000)
                .OrderBy(b=>b.BookId)
                .Select(t => t.Title)
                .ToArray();

            return string.Join(Environment.NewLine, goldenBooksTitles);
        }
    }
}
