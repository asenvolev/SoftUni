﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace CardPower
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var input = Console.ReadLine();
            var sb = new StringBuilder();
            foreach (var suit in Enum.GetValues(typeof(CardSuits)))
            {
                foreach (var rank in Enum.GetValues(typeof(CardRank)))
                {
                    sb.AppendLine($"{rank} of {suit}");
                }
            }
            Console.WriteLine(sb.ToString().TrimEnd());
        }

        private static void PrintAttribute(Type type)
        {
            var attributes = type.GetCustomAttributes(false);
            Console.WriteLine(attributes[0]);
        }

        public static Card ReadCard()
        {
            var cardRank = Console.ReadLine();
            var cardSuit = Console.ReadLine();
            var card = new Card(cardRank, cardSuit);
            return card;
        }
    }
}
