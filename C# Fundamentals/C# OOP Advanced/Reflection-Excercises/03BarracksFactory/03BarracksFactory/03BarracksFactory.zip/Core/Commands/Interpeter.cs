﻿namespace _03BarracksFactory.Core.Commands
{
    using System;
    using Contracts;
    using System.Linq;
    public class Interpeter : Command, ICommandInterpreter
    {
        public Interpeter(string[] data, IRepository repository, IUnitFactory unitFactory)
            : base(data, repository, unitFactory)
        {
        }

        public override string Execute()
        {
            string result = this.InterpredCommand(this.Data, this.Data[0]);
            return result;
        }

        public string InterpredCommand(string[] data, string commandName)
        {
            IExecutable command = this.InterpretCommand(data, commandName);
            var result = command.Execute();
            return result;
        }

        public IExecutable InterpretCommand(string[] data, string commandName)
        {
            string firstChar = commandName.First().ToString().ToUpper();
            string otherLetters = commandName.Substring(1, commandName.Length-1);
            string command = firstChar + otherLetters;

            Type classType = Type.GetType($"_03BarracksFactory.Core.Commands.{command}");
            IExecutable currExe = (IExecutable)Activator.CreateInstance(classType, new object[] { data, this.Repository, this.UnitFactory });
            return currExe;
        }
    }
}
