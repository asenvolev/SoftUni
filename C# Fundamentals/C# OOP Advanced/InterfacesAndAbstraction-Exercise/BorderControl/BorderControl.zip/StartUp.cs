﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BorderControl
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var input = Console.ReadLine();
            var list = new List<IIdentifiable>();
            while (input!="End")
            {
                var tokens = input.Split();
                if (tokens.Length == 2)
                {
                    IIdentifiable robot = new Robot(tokens[0], tokens[1]);
                    list.Add(robot);
                }
                else
                {
                    IIdentifiable citizen = new Citizen(tokens[0], int.Parse(tokens[1]), tokens[2]);
                    list.Add(citizen);
                }
                input = Console.ReadLine();
            }
            input = Console.ReadLine();
            foreach (var id in list.Where(x=>x.Id.EndsWith(input)))
            {
                Console.WriteLine(id.Id);
            }
        }
    }
}
