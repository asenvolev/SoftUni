﻿namespace PhotoShare.Data
{
    internal class ServerConfig
    {
        internal static string ConnectionString => @"Server=(localdb)\MSSQLLocalDB;Database=PhotoShare;Integrated Security=True;";
    }
}
