﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeamBuilder.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=TeamBuilder;Integrated Security=True;";
    }
}
