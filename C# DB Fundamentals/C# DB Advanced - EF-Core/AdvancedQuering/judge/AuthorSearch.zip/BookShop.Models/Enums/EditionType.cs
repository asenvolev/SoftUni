﻿namespace BookShop.Models
{
    public enum EditionType
    {
        Normal,
        Promo,
        Gold
    }
}