﻿namespace BashSoft.Contracts
{
    public interface IDirectoryManager : IDirectoryChanger, IDirectoryTraverser, IDirectoryCreator
    {
    }
}