﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wintellect.PowerCollections;

namespace Problem_3._Text_Editor
{
    class TextEditor : ITextEditor
    {
        private Trie<bool> users;

        private Dictionary<string, Stack<BigList<char>>> cache;

        public TextEditor()
        {
            this.users = new Trie<bool>();
            this.cache = new Dictionary<string, Stack<BigList<char>>>();
        }

        public void Clear(string username)
        {
            this.cache[username].Push(new BigList<char>());
        }

        public void Delete(string username, int startIndex, int length)
        {
            var list = this.cache[username].Peek();

            var newList = new BigList<char>();

            newList.AddRange(list);

            newList.RemoveRange(startIndex, length);

            this.cache[username].Push(newList);
        }

        public void Insert(string username, int index, string text)
        {
            var newList = new BigList<char>();

            var ch = this.cache[username];

            if(this.cache[username].Count!=0)
            {
                var list = this.cache[username].Peek();

                newList.AddRange(list);
            }

            newList.InsertRange(index, text);

            this.cache[username].Push(newList);

        }

        public int Length(string username)
        {
            return this.cache[username].Peek().Count;
        }

        public void Login(string username)
        {
            this.users.Insert(username, true);
            this.cache[username] = new Stack<BigList<char>>();
        }

        public void Logout(string username)
        {
            var value = this.users.GetValue(username);
            value = false;
        }

        public void Prepend(string username, string text)
        {
            this.Insert(username, 0, text);
        }

        public string Print(string username)
        {
            var stack = this.cache[username];

            var list = new BigList<char>();

            if(stack.Count!=0)
            {
                list= this.cache[username].Peek();
            }

            return string.Join("", list);
        }

        public void Substring(string username, int startIndex, int length)
        {
            var list = this.cache[username].Peek();

            var temp = new BigList<char>();

            for (int i = startIndex; i < Math.Min(startIndex + length, list.Count); i++)
            {
                temp.Add(list[i]);
            }

            this.cache[username].Push(temp);
        }

        public void Undo(string username)
        {
            var stack = this.cache[username];

            stack.Pop();
        }

        public IEnumerable<string> Users(string prefix = "")
        {
            Queue<string> queue = new Queue<string>();

            foreach (var user in this.users.GetByPrefix(prefix))
            {
                if(this.users.GetValue(user))
                {

                    queue.Enqueue(user);
                }
            }

            return queue;
        }
    }
}
