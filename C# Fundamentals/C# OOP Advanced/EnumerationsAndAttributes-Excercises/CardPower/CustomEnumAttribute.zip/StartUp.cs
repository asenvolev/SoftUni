﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace CardPower
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var input = Console.ReadLine();
            if (input == "Rank")
            {
                PrintAttribute(typeof(CardRank));
            }
            else
            {
                PrintAttribute(typeof(CardSuits));
            }
        }

        private static void PrintAttribute(Type type)
        {
            var attributes = type.GetCustomAttributes(false);
            Console.WriteLine(attributes[0]);
        }

        public static Card ReadCard()
        {
            var cardRank = Console.ReadLine();
            var cardSuit = Console.ReadLine();
            var card = new Card(cardRank, cardSuit);
            return card;
        }
    }
}
