﻿using System;
using System.Collections.Generic;

public class Trie<Value>
{
    private Node root;

    private class Node
    {
        public Value Value;

        public bool IsTerminal;

        public Dictionary<char, Node> Next = new Dictionary<char, Node>();
    }

    public Value GetValue(string key)
    {
        Node node = this.GetNode(this.root, key, 0);

        if (node == null || !node.IsTerminal)
        {
            throw new InvalidOperationException();
        }

        return node.Value;
    }

    public bool Contains(string key)
    {
        Node node = this.GetNode(this.root, key, 0);

        return node != null && node.IsTerminal;
    }

    public void Insert(string key, Value value)
    {
        this.root = this.Insert(this.root, key, value, 0);
    }

    public IEnumerable<string> GetByPrefix(string prefix)
    {
        Queue<string> results = new Queue<string>();

        Node node = this.GetNode(this.root, prefix, 0);

        this.Collect(node, prefix, results);

        return results;
    }

    private Node GetNode(Node node, string key, int index)
    {
        if (node == null)
        {
            return null;
        }

        if (index == key.Length)
        {
            return node;
        }

        Node nextNode = null;

        char character = key[index];

        if (node.Next.ContainsKey(character))
        {
            nextNode = node.Next[character];
        }

        return this.GetNode(nextNode, key, index + 1);
    }

    private Node Insert(Node node, string key, Value value, int index)
    {
        if (node == null)
        {
            node = new Node();
        }

        if (index == key.Length)
        {
            node.Value = value;

            node.IsTerminal = true;

            return node;
        }

        Node nextNode = null;

        char character = key[index];

        if (node.Next.ContainsKey(character))
        {
            nextNode = node.Next[character];
        }

        node.Next[character] = this.Insert(nextNode, key, value, index + 1);

        return node;
    }

    private void Collect(Node node, string prefix, Queue<string> results)
    {
        if (node == null)
        {
            return;
        }

        if (node.Value != null && node.IsTerminal)
        {
            results.Enqueue(prefix);
        }

        foreach (char character in node.Next.Keys)
        {
            this.Collect(node.Next[character], prefix + character, results);
        }
    }
}